<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller {


    // public function __construct(){
    // parent::__construct();
    // $this->load->model('Home_model');    

	public function index()
	{
		$data['main_content'] = 'Home';
        $this->load->view('includes/template',$data);

	}

    public function about(){
        $data['main_content'] = 'about';
        $this->load->view('includes/template',$data);
    }

    public function services(){
        $data['main_content'] = 'services';
        $this->load->view('includes/template',$data);
    }

    public function contact_us(){
        $data['main_content'] = 'contact_us';
        $this->load->view('includes/template',$data);
    }

    public function project(){
        $data['main_content'] = 'project';
        $this->load->view('includes/template',$data);
    }


    // public function customer_care(){
    //     $data['main_content'] = 'customer_care';
    //     $this->load->view('includes/template', $data);
    //     }    
    
        public function sendMail()
        {
            $input = $this->input->post();
              //print_r($input);die(); 
    
            if($input)
            {   
                $f_name   = $input['f_name'];
                $l_name      = $input['l_name'];
                $email  = $input['email'];
                $phone     = $input['phone'];
                $company_name     = $input['company_name'];
                $message     = $input['message'];
                
                $myemail    = 'eeapl@expanture.in';
    
                $user_msg   = "Welcome!<br><br>Thank you for connecting to Expanture Eletrical &amp; Automation Pvt.Ltd. We value your interest in our company.
                <br>This email is an acknowledgement that we have received your details. Our support team will contact you shortly. Meanwhile, if you want to know more, we kindly request you to visit our website <a href='https://rajlaxmiroadlines.com'>Rajlaxmi Roadlines</a><br>
                    We do appreciate the time you invested in this application.
                    <br><footer>
                        Website: <a href='https://expanture.in'> www.expanture.com</a>
                        <h4 class='wt'><b> Office Address(UK)</b></h4>
                        <address> 
                        Address: Shop No. 03, SR. NO. 78, Hissa No. 01, Dangat Industrial Estate, Shivane, Pune-411023<br>
                        <a href='tel:+919028337954 ' class='wt'><i class='fa fa-phone'></i>+919075211339 </a><br>
                        
                        </address>
                        </footer>";
    
    
                                //show($user_msg);
    
                $dd  = array(
                    'f_name'  => $f_name,
                    'l_name' => $l_name,
                    'email'       => $email,
                    'phone'    => $phone,
                    'company_name' => $company_name,
                    'message'   => $message
                );
    
                $insert_con = $this->db->insert('contact_us',$dd);
    
                //print_r($dd);die();
                $config['protocol']    = 'mail';
                 $config['smtp_host']   = 'mail.expanture.in';
                 $config['smtp_port']   =  465;
                 $config['smtp_user']   = 'eeapl@expanture.in'; 
                 $config['smtp_pass']   = '******'; // change it to yours
                 $config['mailtype']    = 'html';
                 $config['charset']     = 'utf-8';
                 $config['wordwrap']    = TRUE;
    
                $data = "<html>
                             <body>
                                <table>
                                    <tr>
                                    <th style='text-align:center'>Form Submit From Expanture Eletrical</th>
                                    </tr>
                                    <tr>
                                        <td>First Name</td>
                                        <td>".$f_name."</td>
                                    </tr>

                                    <tr>
                                        <td>Last Name</td>
                                        <td>".$l_name."</td>
                                    </tr>

                                    <tr>
                                        <td>Email</td>
                                        <td>".$email."</td>
                                    </tr>
                                    <tr>
                                        <td>Phone</td>
                                        <td>".$phone."</td>
                                    </tr>
    
                                    <tr>
                                        <td>Company Name</td>
                                        <td>".$company_names."</td>
                                    </tr>
    
                                    
                                    <tr>
                                        <td>Message</td>
                                        <td>".$message."</td>
                                    </tr>
                                </table>
                             </body>
                         </html>";
    
                 // print_r($data);die();
                  $this->load->library('email');
                  $this->email->initialize($config);
                  $this->email->set_newline("\r\n");
                  $this->email->from($myemail); // change it to yours 
                  $this->email->to($myemail);
                  $this->email->cc('sampurnapokharkar@gmail.com');
                  //$this->email->bcc('sampurnapokharkar@gmail.com');
                  $this->email->subject('Contact Us Form Submission:Expanture Eletrical');
                  $this->email->message($data);
                
                if($this->email->send())
                 {
                    $this->email->set_newline("\r\n");
                    $this->email->from($myemail); // change it to yours 
                    $this->email->to($email);
                    $this->email->subject('Expanture Eletrical');
                    $this->email->message($user_msg);
                    $this->email->send();
                    
                    $this->session->set_flashdata('msg','Thank you for your input, We will get back to You soon');
                    $this->session->set_flashdata('msg_type','success');
                    // redirect(base_url());
                    redirect(base_url());
                 }
                 else
                {
                  print_r($this->email->print_debugger());
                    $this->session->set_flashdata('msg','Something Went Wrong');
                    $this->session->set_flashdata('msg_type','danger');
                    redirect(base_url());
                }
            }
        } 
    
    
    
        public function request_quotation()
        {
           $input = $this->input->post();
    
           if($input)
            {   
                $request   = $input['request'];
                $location      = $input['location'];
                $city_of_departure     = $input['city_of_departure'];
                $delivery_city     = $input['delivery_city'];
                $weight  = $input['weight'];
                $dimension = $input['dimension'];
                $name = $input['name'];
                $email = $input['email'];
                $phone = $input['phone']; 
                $message     = $input['message'];
                
                $myemail    = 'support@rajlaxmiroadlines.com';
    
                $user_msg   = "Welcome!<br><br>Thank you for connecting to Rajlaxmi Roadlines. We value your interest in our company.<br>This email is an acknowledgement that we have received your details. Our support team will contact you shortly. Meanwhile, if you want to know more, we kindly request you to visit our website <a href='https://rajlaxmiroadlines.com'>Rajlaxmi Roadlines</a><br>
                    We do appreciate the time you invested in this application.
                    <br><footer>
                        Website: <a href='https://rajlaxmiroadlines.com'> www.rajlaxmiroadlines.com</a>
                        <h4 class='wt'><b> Office Address(UK)</b></h4>
                        <address> 
                        Address: Sai Dham Commercial Mall, 2nd Floor, Office No.-45, Landewadi Road, Bhosari Pune 411039<br>
                        <a href='tel:+020-307 14 237 ' class='wt'><i class='fa fa-phone'></i>+020-307 14 237 </a><br>
                        
                        </address>
                        </footer>";
    
    
                                //show($user_msg);
    
                $dd  = array(
                    'request'  => $request,
                    'location'       => $location,
                    'city_of_departure'    => $city_of_departure,
                    'delivery_city' => $delivery_city,
                    'weight' => $weight,
                    'dimension' => $dimension,
                    'name' => $name,
                    'email' => $email,
                    'phone' => $phone,
                    'message'   => $message
                );
    
                $insert_con = $this->db->insert('request_quote',$dd);
    
                //print_r($dd);die();
                $config['protocol']    = 'mail';
                 $config['smtp_host']   = 'mail.rajlaxmiroadlines.com';
                 $config['smtp_port']   =  465;
                 $config['smtp_user']   = 'support@rajlaxmiroadlines.com'; 
                 $config['smtp_pass']   = 'Rjsupport@20200'; // change it to yours
                 $config['mailtype']    = 'html';
                 $config['charset']     = 'utf-8';
                 $config['wordwrap']    = TRUE;
    
                $data = "<html>
                             <body>
                                <table>
                                    <tr>
                                    <th style='text-align:center'>Form Submit From Rajlaxmi Roadlines</th>
                                    </tr>
    
                                    <tr>
                                        <td>Request Type</td>
                                        <td>".$request."</td>
                                    </tr>
    
                                    <tr>
                                        <td>Location</td>
                                        <td>".$location."</td>
                                    </tr>
    
                                    <tr>
                                        <td>City Of Departure</td>
                                        <td>".$city_of_departure."</td>
                                    </tr>
    
                                    <tr>
                                        <td>Delivery City</td>
                                        <td>".$delivery_city."</td>
                                    </tr>
    
                                    <tr>
                                        <td>Weight</td>
                                        <td>".$weight."</td>
                                    </tr>
    
                                    <tr>
                                        <td>Dimension</td>
                                        <td>".$dimension."</td>
                                    </tr>
    
                                    <tr>
                                        <td>Name</td>
                                        <td>".$name."</td>
                                    </tr>
                                    <tr>
                                        <td>Email</td>
                                        <td>".$email."</td>
                                    </tr>
                                    <tr>
                                        <td>Phone</td>
                                        <td>".$phone."</td>
                                    </tr>
    
                                   
                                    <tr>
                                        <td>Message</td>
                                        <td>".$message."</td>
                                    </tr>
                                </table>
                             </body>
                         </html>";
    
                 // print_r($data);die();
                  $this->load->library('email');
                  $this->email->initialize($config);
                  $this->email->set_newline("\r\n");
                  $this->email->from($myemail); // change it to yours 
                  $this->email->to($myemail);
                  $this->email->cc('rahulbangar@rajlaxmiroadlines.com');
                  //$this->email->bcc('sampurnapokharkar@gmail.com');
                  $this->email->subject('Rajlaxmi Roadlines');
                  $this->email->message($data);
                
                if($this->email->send())
                 {
                    $this->email->set_newline("\r\n");
                    $this->email->from($myemail); // change it to yours 
                    $this->email->to($email);
                    $this->email->subject('Request Quotation:Rajlaxmi Roadlines');
                    $this->email->message($user_msg);
                    $this->email->send();
                    
                    $this->session->set_flashdata('msg','Thank you for your input, We will get back to You soon');
                    $this->session->set_flashdata('msg_type','success');
                    // redirect(base_url());
                    redirect(base_url());
                 }
                 else
                {
                  print_r($this->email->print_debugger());
                    $this->session->set_flashdata('msg','Something Went Wrong');
                    $this->session->set_flashdata('msg_type','danger');
                    redirect(base_url());
                }
    
           }     
            
        }
    





//}

}
