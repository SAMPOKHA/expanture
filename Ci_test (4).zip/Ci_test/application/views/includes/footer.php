 <!-- start site-footer -->
 <footer class="site-footer">
            <div class="upper-footer">
                <div class="container">
                    <div class="row">
                        <div class="col col-md-4 col-sm-6">
                            <div class="widget about-widget">
                                <div class="footer-logo"><img src="<?php echo base_url();?>assets/images/expanture.png" alt></div>
                                <ul class="contact-info">
                                    <li><i class="fa fa-home"></i>Shop No. 03, SR. NO. 78, Hissa No. 01, Dangat Industrial Estate, Shivane, Pune-411023</li>
                                    <li><i class="fa fa-phone"></i> Mr. Shriram Sangle         +919028337954<br>
                                                                    
                                                                    Ms. Chaitanya Jawalkoti         +919075211339</li>
                                    
                                </ul>
                            </div>
                        </div>


                        <div class="col col-md-4 col-sm-6">
                            <div class="widget about-widget">
                            <h3></h3>
                                <ul class="contact-info">
                                    
                                    
                                    <li><i class="fa fa-home"></i> Email: <br>eeapl@expanture.in</li>
                                    <li><i class="fa fa-home"></i> Working Hours:<br>9am-5pm</li>
                                    <li><i class="fa fa-home"></i> GST NO:<br>27AAFCE1990B1ZU</li>
                                </ul>
                            </div>
                        </div>

                        
                        <div class="col col-md-4 col-sm-6">
                            <div class="widget quick-links-widget">
                                <h3>Navigation</h3>
                                <ul>
                                    <li><a href="<?php echo base_url();?>">Home</a></li>
                                    <li><a href="<?php echo base_url();?>about">About</a></li>
                                    <li><a href="<?php echo base_url();?>services">Services</a></li>
                                    <li><a href="<?php echo base_url();?>project">Project</a></li>
                                    <li><a href="<?php echo base_url();?>contact_us">Contact</a></li>
                                </ul>
                                
                            </div>
                        </div>

                        
                    </div>
                </div>
            </div> <!-- end upper-footer -->
            <div class="copyright-info">
                <div class="container">
                <p>
                © Copyright <strong>Expanture Eletrical &amp; Automation Pvt.Ltd</strong>. All Rights Reserved
              </p>
              <a href="mailto:eeapl@expanture.in ">
              <a target="_blank" href="<?php echo base_url();?>">Expanture Eletrical &amp; Automation Pvt.Ltd</a>
                    
                </div>
            </div>
        </footer>
        <!-- end site-footer -->
    </div>
    <!-- end of page-wrapper -->



    <!-- All JavaScript files
    ================================================== -->
    <script src="<?php echo base_url();?>assets/js/jquery.min.js"></script>
    <script src="<?php echo base_url();?>assets/js/bootstrap.min.js"></script>

    <!-- Plugins for this template -->
    <script src="<?php echo base_url();?>assets/js/jquery-plugin-collection.js"></script>
    <script src="<?php echo base_url();?>assets/js/jquery.mCustomScrollbar.js"></script>

    <!-- Custom script for this template -->
    <script src="<?php echo base_url();?>assets/js/script.js"></script>
</body>


</html>
