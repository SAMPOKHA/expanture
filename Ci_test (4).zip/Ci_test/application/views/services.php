
        <!-- start page-title -->
        <section class="page-title">
            <div class="container">
                <div class="row">
                    <div class="col col-xs-12">
                        <h2>Services</h2>
                        <ol class="breadcrumb">
                            <li><a href="<?php echo base_url();?>">Home</a></li>
                            <li>Services</li>
                        </ol>
                    </div>
                </div> <!-- end row -->
            </div> <!-- end container -->
        </section>        
        <!-- end page-title -->


        <!-- start of services -->
        <section class="section-padding services-grid-section">
            <div class="container">
                <div class="row">
                    <div class="col col-xs-12">
                        <div class="services-grids services-grid-view">
                            <div class="grid">
                               <div class="inner mk-bg-img">
                                    <div class="details ">
                                       <div class="info">
                                            <img src="<?php echo base_url();?>assets/images/services/img-1.jpg" alt class="bg-image">
                                            <a href="service-single.html">
                                                <h3><i class="fi flaticon-construction"></i> Programming</h3>
                                            </a>
                                            <p>will have to make sure the prototype looks finished by inserting text or photo
                                                make sure the prototype looks finished by.</p>
                                            
                                       </div>
                                    </div>
                               </div>
                            </div>
                            <div class="grid">
                               <div class="inner mk-bg-img">
                                    <div class="details ">
                                       <div class="info">
                                            <img src="<?php echo base_url();?>assets/images/services/img-2.jpg" alt class="bg-image">
                                            <a href="">
                                                <h3><i class="fi flaticon-construction"></i> Design</h3>
                                            </a>
                                            <p>will have to make sure the prototype looks finished by inserting text or photo 
                                                make sure the prototype looks finished by.</p>
                                            <a href="" class="more">Get Details</a>
                                       </div>
                                    </div>
                               </div>
                            </div>
                            <div class="grid">
                               <div class="inner mk-bg-img">
                                    <div class="details ">
                                       <div class="info">
                                            <img src="<?php echo base_url();?>assets/images/services/img-3.jpg" alt class="bg-image">
                                            <a href="">
                                                <h3><i class="fi flaticon-construction"></i> Engineering</h3>
                                            </a>
                                            <p>Ut enim ad minim veniam, quis nos trud exerci tation ullamco.</p>
                                            
                                       </div>
                                    </div>
                               </div>
                            </div>
                            <div class="grid">
                               <div class="inner mk-bg-img">
                                    <div class="details ">
                                       <div class="info">
                                            <img src="<?php echo base_url();?>assets/images/services/img-4.jpg" alt class="bg-image">
                                            <a href="">
                                                <h3><i class="fi flaticon-construction"></i>Commisioning</h3>
                                            </a>
                                            <p>Ut enim ad minim veniam, quis nos trud exerci tation ullamco.</p>
                                            
                                       </div>
                                    </div>
                               </div>
                            </div>
                            <div class="grid">
                               <div class="inner mk-bg-img">
                                    <div class="details ">
                                       <div class="info">
                                            <img src="<?php echo base_url();?>assets/images/services/img-5.jpg" alt class="bg-image">
                                            <a href="">
                                                <h3><i class="fi flaticon-construction"></i> Installation</h3>
                                            </a>
                                            <p>Ut enim ad minim veniam, quis nos trud exerci tation ullamco.</p>
                                            
                                       </div>
                                    </div>
                               </div>
                            </div>
                            <div class="grid">
                               <div class="inner mk-bg-img">
                                    <div class="details ">
                                       <div class="info">
                                            <img src="<?php echo base_url();?>assets/images/services/img-6.jpg" alt class="bg-image">
                                            <a href="">
                                                <h3><i class="fi flaticon-construction"></i> 24/7 Support</h3>
                                            </a>
                                            <p>Ut enim ad minim veniam, quis nos trud exerci tation ullamco.</p>
                                            
                                       </div>
                                    </div>
                               </div>
                            </div>
                        </div> <!-- end services-grids -->
                    </div> <!-- end col -->
                </div> <!-- end row -->

                
            </div> <!-- end container -->
        </section>
        <!-- end of services -->

