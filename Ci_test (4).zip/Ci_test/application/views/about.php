
        <!-- start page-title -->
        <section class="page-title">
            <div class="container">
                <div class="row">
                    <div class="col col-xs-12">
                        <h2>About us</h2>
                        <ol class="breadcrumb">
                            <li><a href="<?php echo base_url();?>">Home</a></li>
                            <li>About us</li>
                        </ol>
                    </div>
                </div> <!-- end row -->
            </div> <!-- end container -->
        </section>        
        <!-- end page-title -->


        <!-- start offer -->
        <section class="section-padding offer-section">
            <div class="container">
                <div class="row">
                    <div class="col col-md-5">
                        <div class="section-title-s3">
                            <h2>About Expanture</h2>
                        </div>                        
                        <div class="offer-text">
                            <p>Over the growing age of automation, we at Expanture Electrical & Automation Pvt. Ltd. aim at delivering our best of 
                                services & custom built solutions in the field of Process, Control Electricals & Industrial Automation</p>
                            <p>To provide one stop solution for all Industrial Electrical products as per customer's demand being our 
                                main goal, we also offer end to end quality of services with smart & precise work flow</p>
                            
                        </div>
                    </div>
                    <div class="col col-md-7">
                        <div class="offer-pic">
                            <img src="<?php echo base_url();?>assets/images/offer-pic.jpg" alt>
                        </div>
                    </div>
                </div> <!-- end row -->
            </div> <!-- end container -->
        </section>
        <!-- end offer -->  


        <!-- start cta -->
        <section class="cta section-padding parallax" data-bg-image="<?php echo base_url();?>assets/images/cta-bg.jpg">
            <div class="container">
                <div class="row">
                    <div class="col col-xs-12">
                        <h2>Our one and only priority is the <span>customer satisfaction</span></h2>
                        <a href="<?php echo base_url('contact_us');?>" class="theme-btn-s5">Get a quote</a>
                    </div>
                </div>
            </div> <!-- end container -->
        </section>
        <!-- end cta -->


        <!-- start features --> 
        <section class="features section-padding">
            <div class="container">
                <div class="row">
                    <div class="col col-md-3">
                        <div class="features-title">
                            <h2>Why we are best</h2>
                            <p>We provide Entire Life Cycle for Industrial Electrical Sector from Engineering
                                 Design to Operational proficiency as per the clients requirements.</p>
                        </div>
                    </div>
                    <div class="col col-md-3 col-sm-4">
                        <div class="feature-grid">
                            <div class="icon">
                                <i class="fi flaticon-people"></i>
                            </div>
                            <div class="details">
                                <h3>Expert Engineers</h3>
                                <p>Sed quia non numquam eius modi tempo ra incidunt ut labore et dolore magnam aliq uam quaera.</p>
                                
                            </div>
                        </div>
                    </div>
                    <div class="col col-md-3 col-sm-4">
                        <div class="feature-grid">
                            <div class="icon">
                                <i class="fi flaticon-support"></i>
                            </div>
                            <div class="details">
                                <h3>Customer Support</h3>
                                <p>Sed quia non numquam eius modi tempo ra incidunt ut labore et dolore magnam aliq uam quaera.</p>
                                
                            </div>
                        </div>
                    </div>
                    <div class="col col-md-3 col-sm-4">
                        <div class="feature-grid">
                            <div class="icon">
                                <i class="fi flaticon-time-passing"></i>
                            </div>
                            <div class="details">
                                <h3>Delivery On time</h3>
                                <p>Sed quia non numquam eius modi tempo ra incidunt ut labore et dolore magnam aliq uam quaera.</p>
                                
                            </div>
                        </div>
                    </div>
                </div>
            </div> <!-- end container -->
        </section> 
        <!-- end features -->


        


        <!-- start fun-fact -->
        <section class="fun-fact">
            <div class="container">
                <div class="row start-count">
                    <div class="col col-sm-4">
                        <div class="grid">
                            <h3><span class="counter" data-count="1200">00</span><span>+</span></h3>
                            <span class="fact-title">Projects</span>
                            <p>inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam</p>
                        </div>
                    </div>
                    <div class="col col-sm-4">
                        <div class="grid">
                            <h3><span class="counter" data-count="800">00</span><span>+</span></h3>
                            <span class="fact-title">Clients</span>
                            <p>inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam</p>
                        </div>
                    </div>
                    <div class="col col-sm-4">
                        <div class="grid">
                            <h3><span class="counter" data-count="99.5">00</span><span>%</span></h3>
                            <span class="fact-title">satisfaction</span>
                            <p>inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam</p>
                        </div>
                    </div>
                </div>
            </div> <!-- end container -->
        </section>
        <!-- end fun-fact -->


        <!-- start partners -->
        <section class="section-padding partners partners-bg">
            <h2 class="hidden">Partners</h2>
            <div class="container">
                <div class="row">
                    <div class="col col-xs-12">
                        <div class="partners-slider">
                            <div class="grid">
                                <img src="<?php echo base_url();?>assets/images/partners/bluestar.jpg" alt>
                            </div>
                            <div class="grid">
                                <img src="<?php echo base_url();?>assets/images/partners/ecofrost.jpg" alt>
                            </div>
                            <div class="grid">
                                <img src="<?php echo base_url();?>assets/images/partners/godrej.jpg" alt>
                            </div>
                            <div class="grid">
                                <img src="<?php echo base_url();?>assets/images/partners/meenergy.png" alt>
                            </div>
                            <div class="grid">
                                <img src="<?php echo base_url();?>assets/images/partners/rakhoh.png" alt>
                            </div>

                            <div class="grid">
                                <img src="<?php echo base_url();?>assets/images/partners/thermax.png" alt>
                            </div>
                        </div>
                    </div>
                </div> <!-- end row -->
            </div> <!-- end container -->
        </section>
        <!-- end partners -->

