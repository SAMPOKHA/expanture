

    <!-- start page-title -->
    <section class="page-title">
        <div class="container">
            <div class="row">
                <div class="col col-xs-12">
                    <h2>Projects</h2>
                    <ol class="breadcrumb">
                        <li><a href="<?php echo base_url();?>">Home</a></li>
                        <li>Projects</li>
                    </ol>
                </div>
            </div> <!-- end row -->
        </div> <!-- end container -->
    </section>        
    <!-- end page-title -->


        <!-- recent-project --> 
    <section class="section-padding projects-grid-view-section">
        <div class="container">
            <div class="row">
                <div class="col col-xs-12">
                    <div class="projects-grid-view">
                        <div class="grid">
                            <div class="project-img">
                                <img src="<?php echo base_url();?>assets/images/projects/g1.png" alt width="390px" height="265px">
                            </div>
                            <div class="project-info">
                                <div class="inner-info">
                                    <a href="#"><h3>Chemical Refinery</h3></a>
                                    <div class="tags">Michigan, US</div>
                                </div>
                            </div>
                        </div>
                        <div class="grid">
                            <div class="project-img">
                            <img src="<?php echo base_url();?>assets/images/projects/g2.png" alt width="390px" height="265px">
                            </div>
                            <div class="project-info">
                                <div class="inner-info">
                                    <a href="#"><h3>Chemical Refinery</h3></a>
                                    <div class="tags">Michigan, US</div>
                                </div>
                            </div>
                        </div>
                        <div class="grid">
                            <div class="project-img">
                            <img src="<?php echo base_url();?>assets/images/projects/g3.png" alt width="390px" height="265px">
                            </div>
                            <div class="project-info">
                                <div class="inner-info">
                                    <a href="#"><h3>Chemical Refinery</h3></a>
                                    <div class="tags">Michigan, US</div>
                                </div>
                            </div>
                        </div>
                        <div class="grid">
                            <div class="project-img">
                            <img src="<?php echo base_url();?>assets/images/projects/g4.png" alt width="390px" height="265px">
                            </div>
                            <div class="project-info">
                                <div class="inner-info">
                                    <a href="#"><h3>Chemical Refinery</h3></a>
                                    <div class="tags">Michigan, US</div>
                                </div>
                            </div>
                        </div>
                        <div class="grid">
                            <div class="project-img">
                            <img src="<?php echo base_url();?>assets/images/projects/g5.png" alt width="390px" height="265px">
                            </div>
                            <div class="project-info">
                                <div class="inner-info">
                                    <a href="#"><h3>Chemical Refinery</h3></a>
                                    <div class="tags">Michigan, US</div>
                                </div>
                            </div>
                        </div>
                        <div class="grid">
                            <div class="project-img">
                            <img src="<?php echo base_url();?>assets/images/projects/g6.png" alt width="390px" height="265px">
                            </div>
                            <div class="project-info">
                                <div class="inner-info">
                                    <a href="#"><h3>Chemical Refinery</h3></a>
                                    <div class="tags">Michigan, US</div>
                                </div>
                            </div>
                        </div>
                        <div class="grid">
                            <div class="project-img">
                            <img src="<?php echo base_url();?>assets/images/projects/g7.png" alt width="390px" height="265px">
                            </div>
                            <div class="project-info">
                                <div class="inner-info">
                                    <a href="#"><h3>Chemical Refinery</h3></a>
                                    <div class="tags">Michigan, US</div>
                                </div>
                            </div>
                        </div>
                        <div class="grid">
                            <div class="project-img">
                            <img src="<?php echo base_url();?>assets/images/projects/g8.png" alt width="390px" height="265px">
                            </div>
                            <div class="project-info">
                                <div class="inner-info">
                                    <a href="#"><h3>Chemical Refinery</h3></a>
                                    <div class="tags">Michigan, US</div>
                                </div>
                            </div>
                        </div>
                        <div class="grid">
                            <div class="project-img">
                            <img src="<?php echo base_url();?>assets/images/projects/g9.png" alt width="390px" height="265px">
                            </div>
                            <div class="project-info">
                                <div class="inner-info">
                                    <a href="#"><h3>Chemical Refinery</h3></a>
                                    <div class="tags">Michigan, US</div>
                                </div>
                            </div>
                        </div>

                        <div class="grid">
                            <div class="project-img">
                            <img src="<?php echo base_url();?>assets/images/projects/g9.png" alt width="390px" height="265px">
                            </div>
                            <div class="project-info">
                                <div class="inner-info">
                                    <a href="#"><h3>Chemical Refinery</h3></a>
                                    <div class="tags">Michigan, US</div>
                                </div>
                            </div>
                        </div>

                        <div class="grid">
                            <div class="project-img">
                            <img src="<?php echo base_url();?>assets/images/projects/g10.png" alt width="390px" height="265px">
                            </div>
                            <div class="project-info">
                                <div class="inner-info">
                                    <a href="#"><h3>Chemical Refinery</h3></a>
                                    <div class="tags">Michigan, US</div>
                                </div>
                            </div>
                        </div>

                        <div class="grid">
                            <div class="project-img">
                            <img src="<?php echo base_url();?>assets/images/projects/g11.png" alt width="390px" height="265px">
                            </div>
                            <div class="project-info">
                                <div class="inner-info">
                                    <a href="#"><h3>Chemical Refinery</h3></a>
                                    <div class="tags">Michigan, US</div>
                                </div>
                            </div>
                        </div>

                        <div class="grid">
                            <div class="project-img">
                            <img src="<?php echo base_url();?>assets/images/projects/g12.png" alt width="390px" height="265px">
                            </div>
                            <div class="project-info">
                                <div class="inner-info">
                                    <a href="#"><h3>Chemical Refinery</h3></a>
                                    <div class="tags">Michigan, US</div>
                                </div>
                            </div>
                        </div>

                        <div class="grid">
                            <div class="project-img">
                            <img src="<?php echo base_url();?>assets/images/projects/g13.png" alt width="390px" height="265px">
                            </div>
                            <div class="project-info">
                                <div class="inner-info">
                                    <a href="#"><h3>Chemical Refinery</h3></a>
                                    <div class="tags">Michigan, US</div>
                                </div>
                            </div>
                        </div>

                        <div class="grid">
                            <div class="project-img">
                            <img src="<?php echo base_url();?>assets/images/projects/g14.png" alt width="390px" height="265px">
                            </div>
                            <div class="project-info">
                                <div class="inner-info">
                                    <a href="#"><h3>Chemical Refinery</h3></a>
                                    <div class="tags">Michigan, US</div>
                                </div>
                            </div>
                        </div>

                        <div class="grid">
                            <div class="project-img">
                            <img src="<?php echo base_url();?>assets/images/projects/g15.png" alt width="390px" height="265px">
                            </div>
                            <div class="project-info">
                                <div class="inner-info">
                                    <a href="#"><h3>Chemical Refinery</h3></a>
                                    <div class="tags">Michigan, US</div>
                                </div>
                            </div>
                        </div>

                        <div class="grid">
                            <div class="project-img">
                            <img src="<?php echo base_url();?>assets/images/projects/g16.png" alt width="390px" height="265px">
                            </div>
                            <div class="project-info">
                                <div class="inner-info">
                                    <a href="#"><h3>Chemical Refinery</h3></a>
                                    <div class="tags">Michigan, US</div>
                                </div>
                            </div>
                        </div>

                        <div class="grid">
                            <div class="project-img">
                            <img src="<?php echo base_url();?>assets/images/projects/g17.png" alt width="390px" height="265px">
                            </div>
                            <div class="project-info">
                                <div class="inner-info">
                                    <a href="#"><h3>Chemical Refinery</h3></a>
                                    <div class="tags">Michigan, US</div>
                                </div>
                            </div>
                        </div>

                        <div class="grid">
                            <div class="project-img">
                            <img src="<?php echo base_url();?>assets/images/projects/g18.png" alt width="390px" height="265px">
                            </div>
                            <div class="project-info">
                                <div class="inner-info">
                                    <a href="#"><h3>Chemical Refinery</h3></a>
                                    <div class="tags">Michigan, US</div>
                                </div>
                            </div>
                        </div>

                        <div class="grid">
                            <div class="project-img">
                            <img src="<?php echo base_url();?>assets/images/projects/g19.png" alt width="390px" height="265px">
                            </div>
                            <div class="project-info">
                                <div class="inner-info">
                                    <a href="#"><h3>Chemical Refinery</h3></a>
                                    <div class="tags">Michigan, US</div>
                                </div>
                            </div>
                        </div>

                        <div class="grid">
                            <div class="project-img">
                            <img src="<?php echo base_url();?>assets/images/projects/g20.png" alt width="390px" height="265px">
                            </div>
                            <div class="project-info">
                                <div class="inner-info">
                                    <a href="#"><h3>Chemical Refinery</h3></a>
                                    <div class="tags">Michigan, US</div>
                                </div>
                            </div>
                        </div>

                        <div class="grid">
                            <div class="project-img">
                            <img src="<?php echo base_url();?>assets/images/projects/g21.png" alt width="390px" height="265px">
                            </div>
                            <div class="project-info">
                                <div class="inner-info">
                                    <a href="#"><h3>Chemical Refinery</h3></a>
                                    <div class="tags">Michigan, US</div>
                                </div>
                            </div>
                        </div>

                        <div class="grid">
                            <div class="project-img">
                            <img src="<?php echo base_url();?>assets/images/projects/g22.png" alt width="390px" height="265px">
                            </div>
                            <div class="project-info">
                                <div class="inner-info">
                                    <a href="#"><h3>Chemical Refinery</h3></a>
                                    <div class="tags">Michigan, US</div>
                                </div>
                            </div>
                        </div>

                        <div class="grid">
                            <div class="project-img">
                            <img src="<?php echo base_url();?>assets/images/projects/g23.png" alt width="390px" height="265px">
                            </div>
                            <div class="project-info">
                                <div class="inner-info">
                                    <a href="#"><h3>Chemical Refinery</h3></a>
                                    <div class="tags">Michigan, US</div>
                                </div>
                            </div>
                        </div>

                        <div class="grid">
                            <div class="project-img">
                            <img src="<?php echo base_url();?>assets/images/projects/g24.png" alt width="390px" height="265px">
                            </div>
                            <div class="project-info">
                                <div class="inner-info">
                                    <a href="#"><h3>Chemical Refinery</h3></a>
                                    <div class="tags">Michigan, US</div>
                                </div>
                            </div>
                        </div>

                        <div class="grid">
                            <div class="project-img">
                            <img src="<?php echo base_url();?>assets/images/projects/g25.png" alt width="390px" height="265px">
                            </div>
                            <div class="project-info">
                                <div class="inner-info">
                                    <a href="#"><h3>Chemical Refinery</h3></a>
                                    <div class="tags">Michigan, US</div>
                                </div>
                            </div>
                        </div>

                        <div class="grid">
                            <div class="project-img">
                            <img src="<?php echo base_url();?>assets/images/projects/g26.png" alt width="390px" height="265px">
                            </div>
                            <div class="project-info">
                                <div class="inner-info">
                                    <a href="#"><h3>Chemical Refinery</h3></a>
                                    <div class="tags">Michigan, US</div>
                                </div>
                            </div>
                        </div>


                        <div class="grid">
                            <div class="project-img">
                            <img src="<?php echo base_url();?>assets/images/projects/g27.png" alt width="390px" height="265px">
                            </div>
                            <div class="project-info">
                                <div class="inner-info">
                                    <a href="#"><h3>Chemical Refinery</h3></a>
                                    <div class="tags">Michigan, US</div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="row more-projects">
                <a href="#" class="theme-btn">More projects</a>
            </div>
        </div> <!-- end container -->
    </section>
    <!-- end recent-project -->        


   