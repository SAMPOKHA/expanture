        <!-- start of hero -->   
        <section class="hero hero-slider-wrapper">
            <div class="hero-slider hero-slider-style-1">
                <div class="slide">
                    <img src="assets/images/slider/slide-1.jpg" alt class="slider-bg">
                    <div class="container">
                        <div class="row">
                            <div class="col col-lg-8 col-sm-9 slide-caption">
                                <h2>We provide the best <span>Industrial</span> Services worldwide</h2>
                                <p>An unknown printer took a galley of type and scrambled it to make a type specimen book.</p>
                                <div class="btns">
                                    <a href="#" class="theme-btn">About us</a>
                                    <a href="#" class="theme-btn-s2">Explore</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="slide">
                    <img src="assets/images/slider/slide-2.jpg" alt class="slider-bg">
                    <div class="container">
                        <div class="row">
                            <div class="col col-lg-8 col-sm-9 slide-caption">
                                <h2>We provide the best <span>Industrial</span> Services worldwide</h2>
                                <p>An unknown printer took a galley of type and scrambled it to make a type specimen book.</p>
                                <div class="btns">
                                    <a href="#" class="theme-btn">About us</a>
                                    <a href="#" class="theme-btn-s2">Explore</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="slide">
                    <img src="assets/images/slider/slide-3.jpg" alt class="slider-bg">
                    <div class="container">
                        <div class="row">
                            <div class="col col-lg-8 col-sm-9 slide-caption">
                                <h2>We provide the best <span>Industrial</span> Services worldwide</h2>
                                <p>An unknown printer took a galley of type and scrambled it to make a type specimen book.</p>
                                <div class="btns">
                                    <a href="#" class="theme-btn">About us</a>
                                    <a href="#" class="theme-btn-s2">Explore</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- end of hero slider -->
        
        
        
        <!-- start of services -->
        <section class="section-padding">
            <div class="container">
                <div class="row">
                    <div class="col col-lg-3 col-md-4">
                        <div class="section-title">
                            <h2>Our services</h2>
                        </div>
                    </div>
                    <div class="col col-lg-6 col-md-5">
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam.</p>
                    </div>
                    <div class="col col-lg-3 col-md-3">
                       <div class="all-service-link">
                            <a href="<?php echo base_url('services');?>" class="theme-btn">All services</a>
                       </div>
                    </div>
                </div> <!-- end row -->
                
                <div class="row">
                    <div class="col col-xs-12">
                        <div class="services-grids service-slider dots-s1">
                            <div class="grid">
                               <div class="inner mk-bg-img">
                                    <div class="details ">
                                       <div class="info">
                                            <img src="<?php echo base_url();?>assets/images/services/img-1.jpg" alt class="bg-image">
                                            <a href="service-single.html">
                                                <h3><i class="fi flaticon-construction"></i> Programming</h3>
                                            </a>
                                            <p>Ut enim ad minim veniam, quis nos trud exerci tation ullamco.</p>
                                            <a href="service-single.html" class="more">Get Details</a>
                                       </div>
                                    </div>
                               </div>
                            </div>
                            <div class="grid">
                               <div class="inner mk-bg-img">
                                    <div class="details ">
                                       <div class="info">
                                            <img src="<?php echo base_url();?>assets/images/services/img-2.jpg" alt class="bg-image">
                                            <a href="service-single.html">
                                                <h3><i class="fi flaticon-construction"></i>Design</h3>
                                            </a>
                                            <p>Ut enim ad minim veniam, quis nos trud exerci tation ullamco.</p>
                                            <a href="service-single.html" class="more">Get Details</a>
                                       </div>
                                    </div>
                               </div>
                            </div>
                            <div class="grid">
                               <div class="inner mk-bg-img">
                                    <div class="details ">
                                       <div class="info">
                                            <img src="<?php echo base_url();?>assets/images/services/img-3.jpg" alt class="bg-image">
                                            <a href="service-single.html">
                                                <h3><i class="fi flaticon-construction"></i> Engineeringy</h3>
                                            </a>
                                            <p>Ut enim ad minim veniam, quis nos trud exerci tation ullamco.</p>
                                            <a href="service-single.html" class="more">Get Details</a>
                                       </div>
                                    </div>
                               </div>
                            </div>
                            <div class="grid">
                               <div class="inner mk-bg-img">
                                    <div class="details ">
                                       <div class="info">
                                            <img src="<?php echo base_url();?>assets/images/services/img-1.jpg" alt class="bg-image">
                                            <a href="service-single.html">
                                                <h3><i class="fi flaticon-construction"></i> Commisioning</h3>
                                            </a>
                                            <p>Ut enim ad minim veniam, quis nos trud exerci tation ullamco.</p>
                                            <a href="service-single.html" class="more">Get Details</a>
                                       </div>
                                    </div>
                               </div>
                            </div>
                        </div> <!-- end services-grids -->
                    </div> <!-- end col -->
                </div> <!-- end row -->
            </div> <!-- end container -->
        </section>
        <!-- end of services -->
        
        
        <!-- start testimonials -->
        <section class="testimonials section-padding parallax" data-bg-image="<?php echo base_url();?>assets/images/testimonials/bg.jpg">
            <div class="container">
                <div class="row">
                    <div class="col col-xs-12">
                        <div class="testimonials-slider slider-arrow-s1">
                            <div class="slide-item">
                                <div class="inner">
                                    <div class="client-quote">
                                        <p>Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.</p>
                                    </div>
                                    <div class="client-details">
                                        <div class="client-pic">
                                            <img src="assets/images/testimonials/client.jpg" alt>
                                        </div>
                                        <div class="client-info">
                                            <h4>Danny Boyles</h4>
                                            <span>Director of Boards, Machinima</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="slide-item">
                                <div class="inner">
                                    <div class="client-quote">
                                        <p>Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.</p>
                                    </div>
                                    <div class="client-details">
                                        <div class="client-pic">
                                            <img src="assets/images/testimonials/client.jpg" alt>
                                        </div>
                                        <div class="client-info">
                                            <h4>Danny Boyles</h4>
                                            <span>Director of Boards, Machinima</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- end testimonials -->


        <!-- start offer -->
        <section class="section-padding">
            <div class="container">
                <div class="row">
                    <div class="col col-md-4">
                        <div class="section-title">
                            <h2>What we offer</h2>
                        </div>
                        <div class="offer-text">
                            <p>Lorem ipsum dolor sit amet, consectetur adipisc ing elit, sed do eiusmod tempor inci didunt ut labore et dolore magna.</p>
                            <p>Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur</p>
                            <a href="#" class="theme-btn read-more">Read More</a>
                        </div>
                    </div>
                    <div class="col col-md-8">
                        <div class="offer-grids">
                            <div class="grid">
                                <div class="details">
                                    <div class="icon">
                                        <i class="fi flaticon-construction"></i> 
                                    </div>
                                    <h3>Advanced Technology</h3>
                                    <p>Sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem.</p>
                                    <a href="#" class="offer-details">Details <i class="fa fa-angle-right"></i></a>
                                </div>
                            </div>
                            <div class="grid">
                                <div class="details">
                                    <div class="icon">
                                        <i class="fi flaticon-people"></i> 
                                    </div>
                                    <h3>Expert Engineers</h3>
                                    <p>Sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem.</p>
                                    <a href="#" class="offer-details">Details <i class="fa fa-angle-right"></i></a>
                                </div>
                            </div>
                            <div class="grid">
                                <div class="details">
                                    <div class="icon">
                                        <i class="fi flaticon-support"></i> 
                                    </div>
                                    <h3>Customer Support</h3>
                                    <p>Sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem.</p>
                                    <a href="#" class="offer-details">Details <i class="fa fa-angle-right"></i></a>
                                </div>
                            </div>
                            <div class="grid">
                                <div class="details">
                                    <div class="icon">
                                        <i class="fi flaticon-time-passing"></i> 
                                    </div>
                                    <h3>Delivery On time</h3>
                                    <p>Sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem.</p>
                                    <a href="#" class="offer-details">Details <i class="fa fa-angle-right"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div> <!-- end row -->
            </div> <!-- end container -->
        </section>
        <!-- end offer -->  


        <!-- recent-project --> 
        <section class="recent-projects section-padding">
            <div class="container">
                <div class="row">
                    <div class="col col-lg-8 col-lg-offset-2">
                        <div class="section-title-s2">
                            <h2>Recent Projects</h2>
                            <p>Lorem ipsum dolor sit amet, mel postea mio liore corrumpit ea. Affert partiendo vix eu. Ei mea dolore democritum disu artio.</p>
                        </div>
                    </div>
                </div> <!-- end row -->
            </div>

            <div class="row">
                <div class="col col-xs-12">
                    <div class="recent-projects-grids">
                        <div class="grid">
                            <div class="project-img">
                                <img src="assets/images/projects/img-1.jpg" alt>
                            </div>
                            <div class="project-info">
                                <div class="inner-info">
                                    <a href="#"><h3>Chemical Refinery</h3></a>
                                    <div class="tags">Michigan, US</div>
                                </div>
                            </div>
                        </div>
                        <div class="grid">
                            <div class="project-img">
                                <img src="assets/images/projects/img-2.jpg" alt>
                            </div>
                            <div class="project-info">
                                <div class="inner-info">
                                    <a href="#"><h3>Chemical Refinery</h3></a>
                                    <div class="tags">Michigan, US</div>
                                </div>
                            </div>
                        </div>
                        <div class="grid">
                            <div class="project-img">
                                <img src="assets/images/projects/img-3.jpg" alt>
                            </div>
                            <div class="project-info">
                                <div class="inner-info">
                                    <a href="#"><h3>Chemical Refinery</h3></a>
                                    <div class="tags">Michigan, US</div>
                                </div>
                            </div>
                        </div>
                        <div class="grid">
                            <div class="project-img">
                                <img src="assets/images/projects/img-4.jpg" alt>
                            </div>
                            <div class="project-info">
                                <div class="inner-info">
                                    <a href="#"><h3>Chemical Refinery</h3></a>
                                    <div class="tags">Michigan, US</div>
                                </div>
                            </div>
                        </div>
                        <div class="grid">
                            <div class="project-img">
                                <img src="assets/images/projects/img-5.jpg" alt>
                            </div>
                            <div class="project-info">
                                <div class="inner-info">
                                    <a href="#"><h3>Chemical Refinery</h3></a>
                                    <div class="tags">Michigan, US</div>
                                </div>
                            </div>
                        </div>
                        <div class="grid">
                            <div class="project-img">
                                <img src="assets/images/projects/img-2.jpg" alt>
                            </div>
                            <div class="project-info">
                                <div class="inner-info">
                                    <a href="#"><h3>Chemical Refinery</h3></a>
                                    <div class="tags">Michigan, US</div>
                                </div>
                            </div>
                        </div>
                        <div class="grid">
                            <div class="project-img">
                                <img src="assets/images/projects/img-3.jpg" alt>
                            </div>
                            <div class="project-info">
                                <div class="inner-info">
                                    <a href="#"><h3>Chemical Refinery</h3></a>
                                    <div class="tags">Michigan, US</div>
                                </div>
                            </div>
                        </div>
                        <div class="grid">
                            <div class="project-img">
                                <img src="assets/images/projects/img-4.jpg" alt>
                            </div>
                            <div class="project-info">
                                <div class="inner-info">
                                    <a href="#"><h3>Chemical Refinery</h3></a>
                                    <div class="tags">Michigan, US</div>
                                </div>
                            </div>
                        </div>
                        <div class="grid">
                            <div class="project-img">
                                <img src="assets/images/projects/img-5.jpg" alt>
                            </div>
                            <div class="project-info">
                                <div class="inner-info">
                                    <a href="#"><h3>Chemical Refinery</h3></a>
                                    <div class="tags">Michigan, US</div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- end recent-project -->


        


        


       